<?php 
  session_start();
  include('../include.php');

?>
<!DOCTYPE html>
<html>
<head>

  <!-- meta -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- title -->
  <title>Aplikasi BalitaKu</title>

  <!-- css -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.12.5/sweetalert2.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
</head>
 
<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 fixed-top">
    <a class="navbar-brand ml-5" href="../">BalitaKu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" style="float: right;"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
      </li>
    </ul>
    <ul class="navbar-nav nav mr-5">
      <li class="nav-item">
        <a class="nav-link text-primary " href="index.php">Beranda</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="dokter.php">Daftar Dokter</a>
      </li>
      <?php 
      
        if (isset($_SESSION['id_user'])){
          // var_dump($_SESSION['id_user']);
          echo '<a class="nav-link text-primary" href="riwayat.php">Riwayat</a>';
        }

        if (isset($_SESSION['id_admin'])) {
          echo '<li class="nav-item"><a class="nav-link text-primary" href="../admin/">Admin Panel</a></li>';
        }
      ?>
      <li class="nav-item">
        <?php 
        if (isset($_SESSION['id_user']) or isset($_SESSION['id_admin'])){
          // var_dump($_SESSION['id_user']);
          echo '<a class="nav-link text-primary" href="../logout.php">Logout</a>';
        } else {
          echo '<a class="nav-link text-primary" href="../login.php">Login</a>';
        }
      ?>
      </li>
    </ul>
  </div>
</nav>

<section id="portfolio" class="portfolio">
<div class="container mt-5" style="margin-bottom: 10%;">

<div class="row">
  <div class="col mt-5">
    <div class="d-flex flex-column text-center">
      <h2 class="text-serif font-weight-bold">Daftar Dokter</h2>
    </div>
  </div>
</div>

<div class="row mt-3">
  <div class="col-md-12">
      <select class="custom-select" id="selectBox" onchange="changeFunc();" required name="pilihan">
        <option value="0" selected>Pilih Lokasi Kelurahan</option>
        <option value="1">Bugangan</option>
        <option value="2">Karangtempel</option>
        <option value="3">Karangturi</option>
        <option value="4">Kebonagung</option>
      </select>
  </div>
</div>

<div class="row mt-3" id="dokter0">
  <?php  
    $sql    = "SELECT * FROM tabel_dokter";
    $result = $konek->query($sql);

    if ($result) {
      while($row = $result->fetch_array()) {?>
        <div class="col-md-6">
          <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters">
              <div class="col-md-4 mt-4">
                <img src="<?php echo '../assets/images/dokter/'.$row['foto']?>" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $row['nama_dokter']?></h4>
                  <p class="card-text"><?php echo $row['deskripsi']?>.</p>
                  <p class="card-text"><small class="text-muted"><?php echo "Tersedia Pukul: ".$row['jam_kerja']?></small></p>
                </div>
              </div>
            </div>
            <div class="card-footer">
                  <h5 class="text-bold text-center text-primary">Puskesmas Bandarharjo</h5>
                </div>
          </div>
        </div>              
  <?php }}?>
</div>

<div class="row mt-3" id="dokter1" style="display:none;">
  <?php  
    $sql    = "SELECT * FROM tabel_dokter WHERE lokasi='1'";
    $result = $konek->query($sql);

    if ($result) {
      while($row = $result->fetch_array()) {?>
        <div class="col-md-6">
          <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters">
              <div class="col-md-4 mt-4">
                <img src="<?php echo '../assets/images/dokter/'.$row['foto']?>" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $row['nama_dokter']?></h4>
                  <p class="card-text"><?php echo $row['deskripsi']?>.</p>
                  <p class="card-text"><small class="text-muted"><?php echo "Tersedia Pukul: ".$row['jam_kerja']?></small></p>
                </div>
              </div>
            </div>
            <div class="card-footer">
                  <h5 class="text-bold text-center text-primary">Puskesmas Bandarharjo</h5>
                </div>
          </div>
        </div>              
  <?php }}?>
</div>

<div class="row mt-3" id="dokter2" style="display:none;">
  <?php  
    $sql    = "SELECT * FROM tabel_dokter WHERE lokasi='2'";
    $result = $konek->query($sql);

    if ($result) {
      while($row = $result->fetch_array()) {?>
        <div class="col-md-6">
          <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters">
              <div class="col-md-4 mt-4">
                <img src="<?php echo '../assets/images/dokter/'.$row['foto']?>" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $row['nama_dokter']?></h4>
                  <p class="card-text"><?php echo $row['deskripsi']?>.</p>
                  <p class="card-text"><small class="text-muted"><?php echo "Tersedia Pukul: ".$row['jam_kerja']?></small></p>
                </div>
              </div>
            </div>
            <div class="card-footer">
                  <h5 class="text-bold text-center text-primary">Puskesmas Banget Ayu</h5>
                </div>
          </div>
        </div>              
  <?php }}?>
</div>

<div class="row mt-3" id="dokter3" style="display:none;">
  <?php  
    $sql    = "SELECT * FROM tabel_dokter WHERE lokasi='3'";
    $result = $konek->query($sql);

    if ($result) {
      while($row = $result->fetch_array()) {?>
        <div class="col-md-6">
          <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters">
              <div class="col-md-4 mt-4">
                <img src="<?php echo '../assets/images/dokter/'.$row['foto']?>" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $row['nama_dokter']?></h4>
                  <p class="card-text"><?php echo $row['deskripsi']?>.</p>
                  <p class="card-text"><small class="text-muted"><?php echo "Tersedia Pukul: ".$row['jam_kerja']?></small></p>
                </div>
              </div>
            </div>
            <div class="card-footer">
                  <h5 class="text-bold text-center text-primary">Puskesmas Candilama</h5>
                </div>
          </div>
        </div>              
  <?php }}?>
</div>

<div class="row mt-3" id="dokter4" style="display:none;">
  <?php  
    $sql    = "SELECT * FROM tabel_dokter WHERE lokasi='4'";
    $result = $konek->query($sql);

    if ($result) {
      while($row = $result->fetch_array()) {?>
        <div class="col-md-6">
          <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters">
              <div class="col-md-4 mt-4">
                <img src="<?php echo '../assets/images/dokter/'.$row['foto']?>" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $row['nama_dokter']?></h4>
                  <p class="card-text"><?php echo $row['deskripsi']?>.</p>
                  <p class="card-text"><small class="text-muted"><?php echo "Tersedia Pukul: ".$row['jam_kerja']?></small></p>
                </div>
              </div>
            </div>
            <div class="card-footer">
                  <h5 class="text-bold text-center text-primary">Puskesmas Genuk</h5>
                </div>
          </div>
        </div>              
  <?php }}?>
</div>

</div>
</section>

  <div class="text-black text-center p-3 fixed-bottom" style="background-color: #f0f0f0">
      Crafted with <span style="color: red;">&#9829;</span> by
      <a class="text-black" href="https://github.com/OnlyHen/">Mahendra</a>
      <br>2019-2021
  </div>
    
  <!-- javascript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.6.0/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.12.5/sweetalert2.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/js/script.js"></script>
  <script>
  $('select#selectBox').change(function(){
      var value = $(this).val()

      if(value == '1'){
          $('#dokter1').show()
          $('#dokter2').hide()
          $('#dokter3').hide()
          $('#dokter4').hide()
          $('#dokter0').hide()
      } else if (value == '2'){
          $('#dokter2').show()
          $('#dokter1').hide()
          $('#dokter3').hide()
          $('#dokter4').hide()
          $('#dokter0').hide()
      } else if (value == '3'){
          $('#dokter3').show()
          $('#dokter1').hide()
          $('#dokter2').hide()
          $('#dokter4').hide()
          $('#dokter0').hide()
      } else if (value == '4'){
          $('#dokter4').show()
          $('#dokter1').hide()
          $('#dokter2').hide()
          $('#dokter3').hide()
          $('#dokter0').hide()
      } 
  });
</script>
</body>

</html>
