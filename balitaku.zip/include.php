<?php  
	$host 		= "localhost";
	$username 	= "id17108678_balitaku";
	$password 	= "^A32ubXSUW3YnM=+";
	$db 		= "id17108678_db_balitaku";

	// $hai = mysqli_connect($host, $username, $password, $db);
	$konek = new mysqli($host, $username, $password, $db) or die("Gagal Konek");
?>