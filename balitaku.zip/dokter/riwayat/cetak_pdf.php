<?php
session_start();
ob_start();
include "../../include.php";
include("../check.php");
$nama_dokter = $_SESSION['dokter'];
// $hasil=mysqli_query($mysqli,"SELECT * FROM hasil WHERE username='$_GET[username]'");
$hasil = $konek->query("SELECT * FROM riwayat WHERE dokter = '$nama_dokter'");

$content = '
	<style type="text/css">
		table{border-collapse: collapse; width: 100%; border:1px solid #e0e0e0;}
		table th{padding: 10px; background:#f8f8f8;}
		table td{padding: 10px;}
	</style>
';

$content .= '
	<page>

		<div style="padding:10px; background:#2196f3; color:#fff; text-align:center;">
			<span>LAPORAN HASIL PEMERIKSAAN</span>
		</div>
		<div style="padding:15px; text-align:center;">
			<span>DATA HASIL PEMERIKSAAN</span>
		</div>
		
		<div style="width:100%;">
			<table align="center" border="1px" class="tabel" style="width:100%;" >
				<tr>
			        <th>No</th>
			        <th>Nama Balita</th>
			        <th>Tanggal Periksa</th>
			        <th>Nama Dokter</th>
			        <th>Keluhan</th>
			        <th>Catatan Dokter</th>
			      </tr>';
			$no = 0;
			while($row = $hasil->fetch_array()){ 
			$no++;
				$content .= '
					<tr>
						<td>'. $no .'</td>
						<td>'.$row["nama_pasien"].'</td>
						<td>'.$row["tgl_periksa"].'</td>
						<td>'.$row["dokter"] .'</td>
						<td>'.$row["keluhan"] .'</td>
						<td>'.$row["catatan"] .'</td>
					</tr>
				';
			}

$content .= '
			</table>
		</div>

	</page>
';

require_once '../../html2pdf/html2pdf.class.php';
$pdf = new HTML2PDF('p','A4','en');
$pdf->WriteHTML($content);
ob_end_clean();
$pdf->Output('Riwayat.pdf', 'FI');
// $pdf->Output('DataDokter.pdf');
?>
