<?php
session_start();
include("../../include.php");
include("../check.php");
// Skrip berikut ini adalah skrip yang bertugas untuk meng-export data tadi ke excell
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=riwayat.xls");
?>
		
<div class="table-responsive">
  <table class="table table-striped shadow-sm" id="myTable">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Balita</th>
        <th>Tanggal Periksa</th>
        <th>Nama Dokter</th>
        <th>Keluhan</th>
        <th>Catatan Dokter</th>
      </tr>
    </thead>
    <tbody>
        <?php  
          $nama_dokter = $_SESSION['dokter'];
          $data = $konek->query("SELECT * FROM riwayat WHERE dokter = '$nama_dokter' ");
          $i = 1;
          while($row = $data->fetch_array()){

            echo "<tr>
                    <td><small>$i</small></td>
                    <td><small>".$row['nama_pasien']."</small></td>
                    <td><small>".$row['tgl_periksa']."</small></td>
                    <td><small>".$row['dokter']."</small></td>
                    <td><small>".$row['keluhan']."</small></td>
                    <td><small>".$row['catatan']."</small></td>
                  </tr>";

            $i++;

            // code...
          }

        ?>
    </tbody>
  </table>
</div>
