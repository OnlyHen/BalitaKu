<?php 
  session_start();
  include("../../include.php");
  include("../check.php");

  $data_anak = $konek->query("SELECT nama_anak, nik_anak FROM data_anak");
  // var_dump($data_anak->fetch_row());      

  if(isset($_POST['submit'])){
    $tgl = $_POST['tanggal_periksa'];
    $keluhan = $_POST['keluhan'];
    $catatan = $_POST['catatan'];
    $dokter = $_SESSION['dokter'];
    $split = explode("|", $_POST['nama_anak']);
    $nama_anak = $split[1];
    $nik_anak = $split[0];
    $input = $konek->query("INSERT INTO riwayat(nama_pasien, keluhan, catatan, dokter, tgl_periksa, nik_anak) VALUES('$nama_anak', '$keluhan', '$catatan', '$dokter', '$tgl', '$nik_anak')");

    if($input){
      echo "<script>alert('Sukses Input Data'); window.location = 'index.php'</script>";
    } else {
      echo "<script>alert('Gagal Input Data'); window.location = 'index.php'</script>";
    }

  }

?>
<!DOCTYPE html>
<html>

<head>

  <!-- meta -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- title -->
  <title>Aplikasi BalitaKu</title>

  <!-- css -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.12.5/sweetalert2.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
</head>
 
<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 fixed-top">
    <a class="navbar-brand ml-5" href="../">BalitaKu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" style="float: right;"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
      </li>
    </ul>
    <ul class="navbar-nav nav mr-5">
      <li class="nav-item">
        <a class="nav-link text-primary" href="../">Beranda</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active " href="index.php">Riwayat</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-primary " href="../user">Pasien</a>
      </li>
      <li class="nav-item">
      <?php 
        if (isset($_SESSION['id_admin'])){
          // var_dump($_SESSION['id_user']);
          echo '<a class="nav-link text-primary" href="../../logout.php">Logout</a>';
        } else {
          echo '<a class="nav-link text-primary" href="../login.php">Login</a>';
        }
      ?>
      </li>
    </ul>
  </div>
  </nav>

<div class="container mt-5" style="margin-bottom: 10%;">

<div class="row">
  <div class="col mt-5">
    <div class="d-flex flex-column text-center">
      <h2 class="text-serif font-weight-bold text-primary">Tambah Data Periksa Dokter</h2>
    </div>
  </div>
</div>
<div class="row">
    <div class="col">
      <div class="card-header py-3 bg-white">
        <button class="btn btn-primary" name="">
            <i class="fa fa-trash-o fa-arrow-left"><a href="index.php" class="text-white"> Kembali</a></i>
        </button>
      </div><br>  
      
      <div class="row">
        <div class="col-md-12 m-auto">


          <div class="d-flex justify-content-center align-items-center flex-wrap flex-column">
            <h4 class="text-black mb-4">Form Pemeriksaan</h4>
          </div>

          <div class="container">
            <form action="" method="post">
              <div class="form-group">
                <input type="text" name="nama_dokter" class="form-control p-4" id="nama_ibu" value="<?= $_SESSION['dokter'] ?>" autocomplete="off" disabled>
              </div>
              <div class="form-group">
                  <select class="custom-select" name="nama_anak">
                    <option value="0" selected>&nbspPilih Pasien</option>
                    <?php
                      $i = 1; 
                      while ($row = $data_anak->fetch_array()) {
                        echo "<option value=".$row['nik_anak']."|".$row['nama_anak'].">".$row['nama_anak']."</option>";
                        $i++;
                      }
                    ?>
                  </select>
              </div>
              <div class="form-group">
                <input type="text" name="tanggal_periksa" class="form-control" placeholder="   Masukkan Tanggal Periksa" onfocus="(this.type='date')" onblur="if(this.value==''){this.type='text'}" required>
              </div>
              <div class="form-group">
                <input type="text" name="keluhan" class="form-control p-4" id="keluhan" placeholder="Masukkan Keluhan" autocomplete="off" required>
              </div>
              <div class="form-group">
                <input type="text" name="catatan" class="form-control p-4" id="catatan" placeholder="Masukkan Catatan Dokter" autocomplete="off" required>
              </div>
              <button type="submit" name="submit" class="btn btn-primary text-light btn-block p-3">
                <i class="fas fa-fw fa-sign-in-alt mr-1"></i>
                <span>Daftar</span>
              </button>       
              <hr>  
            </form>
          </div>

        </div>
      </div>


    </div>
  </div>

</div>


  <div class="text-black text-center p-3 fixed-bottom" style="background-color: #f0f0f0">
      Crafted with <span style="color: red;">&#9829;</span> by
      <a class="text-black" href="https://github.com/OnlyHen/">Mahendra</a>
      <br>2019-2021
  </div>
    
  <!-- javascript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.6.0/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.12.5/sweetalert2.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/js/script.js"></script>
</body>

</html>
