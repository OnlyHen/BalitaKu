<?php  

	if(!isset($_SESSION['id_admin'])){
		echo "<script>alert('Login dulu yh'); window.location = '../index.php'</script>";
	}

?>