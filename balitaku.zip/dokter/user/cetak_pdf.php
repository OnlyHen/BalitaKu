<?php
session_start();
include "../../include.php";
include("../check.php");
ob_start();
// $hasil=mysqli_query($mysqli,"SELECT * FROM hasil WHERE username='$_GET[username]'");
$hasil = $konek->query("SELECT * FROM data_anak");

$content = '
	<style type="text/css">
		table{border-collapse: collapse; width: 100%; border:1px solid #e0e0e0;}
		table th{padding: 10px; background:#f8f8f8;}
		table td{padding: 10px;}
	</style>
';

$content .= '
	<page>

		<div style="padding:10px; background:#2196f3; color:#fff; text-align:center;">
			<span>LAPORAN DAFTAR PASIEN</span>
		</div>
		<div style="padding:15px; text-align:center;">
			<span>DATA DAFTAR PASIEN</span>
		</div>
		
		<div style="width:100%;">
			<table align="center" border="1px" class="tabel" style="width:100%;" >
				<tr>
			      <th>No</th>
	              <th>NIK Anak</th>
	              <th>Nama Anak</th>
	              <th>Tanggal Lahir</th>
	              <th>Nama Ibu</th>
	              <th>Berat Badan Anak</th>
			      </tr>';
			$no = 0;
			while($row = $hasil->fetch_array()){ 
			$no++;
				$content .= '
					<tr>
						<td>'. $no .'</td>
						<td>'.$row["nik_anak"].'</td>
						<td>'.$row["nama_anak"].'</td>
						<td>'.$row["tgllhr"] .'</td>
						<td>'.$row["nama_ibu"] .'</td>
						<td>'.$row["bb_anak"] .'</td>
					</tr>
				';
			}

$content .= '
			</table>
		</div>

	</page>
';

require_once '../../html2pdf/html2pdf.class.php';
$pdf = new HTML2PDF('p','A4','en');
$pdf->WriteHTML($content);
ob_end_clean();
$pdf->Output('Pasien.pdf', 'FI');
// $pdf->Output('DataDokter.pdf');
?>
