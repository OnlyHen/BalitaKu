<?php
session_start();
include("../../include.php");
include("../check.php");
// Skrip berikut ini adalah skrip yang bertugas untuk meng-export data tadi ke excell
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=riwayat.xls");
?>
		
<div class="table-responsive">
  <table class="table table-striped shadow-sm" id="myTable">
    <thead>
      <tr>
        <th>No</th>
        <th>NIK Anak</th>
        <th>Nama Anak</th>
        <th>Tanggal Lahir</th>
        <th>Nama Ibu</th>
        <th>Berat Badan Anak</th>
      </tr>
    </thead>
    <tbody>
              <?php  
                $data = $konek->query("SELECT * FROM data_anak");
                $i = 1;
                while($row = $data->fetch_array()){

                  echo "<tr>
                          <td><small>$i</small></td>
                          <td><small>".$row['nik_anak']."</small></td>
                          <td><small>".$row['nama_anak']."</small></td>
                          <td><small>".$row['tgllhr']."</small></td>
                          <td><small>".$row['nama_ibu']."</small></td>
                          <td><small>".$row['bb_anak']."</small></td>
                        </tr>";

                  $i++;

                  // code...
                }

              ?>
              
          </tbody>
  </table>
</div>
