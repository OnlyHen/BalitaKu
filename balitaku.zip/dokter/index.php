<?php 
  session_start();

  if(!isset($_SESSION['id_admin'])){
    header("Location: login.php");
  }

?>
<!DOCTYPE html>
<html>

<head>

  <!-- meta -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- title -->
  <title>Admin Panel - Aplikasi BalitaKu</title>

  <!-- css -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.12.5/sweetalert2.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
</head>
 
<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 fixed-top">
    <a class="navbar-brand ml-5" href="index.php">BalitaKu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" style="float: right;"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
      </li>
    </ul>
    <ul class="navbar-nav nav mr-5">
      <li class="nav-item">
        <a class="nav-link  active" href="index.php">Beranda</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-primary " href="riwayat/">Riwayat</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-primary " href="user/">Pasien</a>
      </li>
      <li class="nav-item">
      <?php 
        if (isset($_SESSION['id_admin'])){
          // var_dump($_SESSION['id_user']);
          echo '<a class="nav-link text-primary" href="../logout.php">Logout</a>';
        } else {
          echo '<a class="nav-link text-primary" href="login.php">Login</a>';
        }
      ?>
      </li>
    </ul>
  </div>
</nav>


<div class="container mt-5" style="margin-bottom: 5%;">

  <div class="row">
    <div class="col-md-6">
      <!-- gambar -->
      <img src="https://static.vecteezy.com/system/resources/previews/001/418/291/non_2x/childbirth-at-hospital-flat-illustration-vector.jpg" alt="" class="img-fluid mt-5 mb-5">
    </div>
    <div class="col-md-6 m-auto">
      <h3>Selamat Datang Di Aplikasi <strong class="text-primary">BalitaKu</strong></h3>
      <span class="text-blqck-50 d-block mb-3">BalitaKu adalah sebuah aplikasi penghubung antara anda dan instansi kesehatan terdekat demi kesehatan anda dan putra / putri anda.  </span>
      <a href="riwayat/" class="btn btn-primary text-light">
        <small class="fas fa-fw fa-sticky-note mr-1"></small>
        <small>Lihat Daftar Periksa</small>
      </a>
    </div>
  </div>

</div>


  <div class="text-black text-center p-3 fixed-bottom" style="background-color: #f0f0f0">
      Crafted with <span style="color: red;">&#9829;</span> by
      <a class="text-black" href="https://github.com/OnlyHen/">Mahendra</a>
      <br>2019-2021
  </div>
    
  <!-- javascript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.6.0/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.12.5/sweetalert2.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/js/script.js"></script>
</body>

</html>
